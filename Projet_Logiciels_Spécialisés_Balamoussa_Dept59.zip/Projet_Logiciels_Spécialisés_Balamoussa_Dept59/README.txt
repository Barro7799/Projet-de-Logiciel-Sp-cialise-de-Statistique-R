=================================================
PROJET LOGICIELS SPÉCIALISÉS EN STATISTIQUE
Analyse des revenus et de la pauvreté en France
=================================================
INFORMATIONS ÉTUDIANT
---------------------
Nom : BARRO
Prénom : Balamoussa
Département choisi : 59 (Nord)
Année : 2ème année Statistique et Informatique
Date de rendu : Le 08 février 2026

================================================================================
CONTENU DU DOSSIER
------------------
1. Projet_Logiciels_Spécialisé_Balamoussa_Dept59.Rmd  : Fichier R Markdown source
2. Projet_Logiciels_Spécialisé_Balamoussa_Dept59.html : Rapport HTML compilé
3. README.txt                                         : Ce fichier

================================================================================
FIN DU FICHIER README
================================================================================
